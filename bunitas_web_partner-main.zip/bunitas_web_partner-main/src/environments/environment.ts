/*
  Authors : cosonas (Rahul Jograna)
  Website : https://cosonas.com/
  App Name : Bunitas Management Full App Flutter
  This App Template Source code is licensed as per the
  terms found in the Website https://cosonas.com/license
  Copyright and Good Faith Purchasers © 2022-present cosonas.
*/
export const environment = {
  production: false,
  // baseUrl: 'https://api.bunitas.com/api/',
  // imageUrl: 'https://api.bunitas.com/storage/images/',
  baseUrl: 'http://192.168.144.241:8000/api/',
  imageUrl: 'http://192.168.144.241:8000/storage/images/',
};
