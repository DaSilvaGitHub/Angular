
/*
  Authors : cosonas (Rahul Jograna)
  Website : https://cosonas.com/
  App Name : Bunitas Management Full App Flutter
  This App Template Source code is licensed as per the
  terms found in the Website https://cosonas.com/license
  Copyright and Good Faith Purchasers © 2022-present cosonas.
*/
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocsLinkComponent } from './docs-link.component';

describe('DocsLinkComponent', () => {
  let component: DocsLinkComponent;
  let fixture: ComponentFixture<DocsLinkComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DocsLinkComponent]
    })
      .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocsLinkComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
