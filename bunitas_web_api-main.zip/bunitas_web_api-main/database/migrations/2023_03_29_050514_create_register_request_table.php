<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('register_request', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('country_code');
            $table->string('mobile');
            $table->string('cover')->nullable();
            $table->tinyInteger('gender')->nullable();
            $table->string('type')->nullable(); //admin // user // salon // freelancer
            $table->string('sub_type')->nullable();
            $table->text('zipcode')->nullable();
            $table->text('categories')->nullable();
            $table->text('address')->nullable();
            $table->string('lat')->nullable();
            $table->string('lng')->nullable();
            $table->text('policy')->nullable();
            $table->string('name');
            $table->text('about')->nullable();
            $table->double('fee_start',10,2)->default(0);
            $table->string('cid')->nullable();
            $table->string('dob')->nullable();
            $table->string('id_card')->nullable();
            $table->string('qualification')->nullable();
            $table->string('social')->nullable();
            $table->text('extra_field')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('register_request');
    }
};
