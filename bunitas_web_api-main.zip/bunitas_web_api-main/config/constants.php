<?php

return [
    'partnerTypes' => ['Mobile Beautician','Hair & Nails Salon','Barber Shop','Wellness & Spa','Beauty Clinics','Products Only']
];
